package com.example.demo.security;

import com.example.demo.exception.ApiErrorResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.Instant;

@Component
@RequiredArgsConstructor
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private final ObjectMapper objectMapper; // تزریق از طریق Spring Bean

    @Override
    public void commence(HttpServletRequest request,
                         HttpServletResponse response,
                         AuthenticationException authException) throws IOException {

        // ساخت پاسخ طبق استاندارد RFC 7807 با استفاده از Builder
        ApiErrorResponse errorResponse = ApiErrorResponse.builder()
                .type("about:blank")
                .title("Unauthorized")
                .status(HttpStatus.UNAUTHORIZED.value())
                .detail(authException.getMessage() != null ? authException.getMessage() : "Full authentication is required to access this resource")
                .instance(request.getRequestURI())
                .timestamp(Instant.now())
                .build();

        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);

        // نوشتن پاسخ به صورت JSON
        response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
    }
}
